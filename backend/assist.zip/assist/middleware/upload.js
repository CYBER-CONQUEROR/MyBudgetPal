
// assist/middleware/upload.js
import multer from "multer";
export const upload = multer({ dest: "uploads/" });
