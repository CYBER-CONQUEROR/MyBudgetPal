// assist/realtimeRoute.js
import { Router } from "express";
const router = Router();

/**
 * POST /api/assist/realtime-token
 * Returns: { client_secret: { value: "<ephemeral_token>", expires_at: <unix> } }
 *
 * The client uses this ephemeral token to open a WebRTC session directly
 * with OpenAI's Realtime API. Your real OPENAI_API_KEY never leaves the server.
 */
router.post("/realtime-token", async (req, res) => {
  try {
    const model = req.body?.model || "gpt-4o-realtime-preview-2024-12-17"; // pick a realtime-capable model
    const r = await fetch("https://api.openai.com/v1/realtime/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        // optional default voice for the model's audio output
        voice: "alloy",
        // You can preload system instructions:
        instructions:
          "You are My Budget Pal. Be concise, friendly, and helpful about personal finance.",
        // Optional: turn on server VAD (auto endpointing)
        // turn_detection: "server_vad",
      }),
    });

    if (!r.ok) {
      const err = await r.text();
      return res.status(500).json({ error: "create_session_failed", detail: err });
    }
    const json = await r.json();
    return res.json(json);
  } catch (e) {
    return res.status(500).json({ error: "realtime_token_failed", detail: e?.message });
  }
});

export default router;
