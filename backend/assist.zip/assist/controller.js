// assist/controller.js
import "dotenv/config";
import fs from "fs";
import mongoose from "mongoose";
import OpenAI from "openai";
import { toFile } from "openai/uploads";
import Account from "../AccountManagement/AccountModel.js";

// ---------- simple OpenAI client (lazy) ----------
let _oai = null;
function oai() {
  if (_oai) return _oai;
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY not set");
  _oai = new OpenAI({ apiKey: key });
  return _oai;
}

// ---------- constants ----------
const BANKS_LK = [
  "Bank of Ceylon (BOC)", "People's Bank", "National Savings Bank (NSB)",
  "Commercial Bank of Ceylon", "Hatton National Bank (HNB)", "Sampath Bank",
  "Seylan Bank", "DFCC Bank", "Nations Trust Bank", "NDB Bank (National Development Bank)",
  "Pan Asia Bank", "Union Bank of Colombo", "Cargills Bank", "Amãna Bank",
  "HSBC Sri Lanka", "Standard Chartered Sri Lanka", "Citibank Sri Lanka",
  "State Bank of India - Sri Lanka", "Indian Bank - Sri Lanka", "Indian Overseas Bank - Sri Lanka",
  "Habib Bank Ltd (HBL)", "MCB Bank", "Public Bank Berhad - Sri Lanka", "Other",
];

const isObjId = (v) => mongoose.isValidObjectId(v);
const toCents = (lkr) => Math.round(Number(lkr || 0) * 100);
const hasExt = (n) => /\.[a-z0-9]+$/i.test(n);
function guessExt(mime) {
  if (!mime) return null;
  if (mime.includes("webm")) return "webm";
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("mpeg")) return "mp3";
  if (mime.includes("mp3")) return "mp3";
  if (mime.includes("wav")) return "wav";
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("m4a")) return "m4a";
  if (mime.includes("flac")) return "flac";
  return null;
}

// ---------- ultra-simple add-account text parser ----------
// Supported examples (no AI, just regex):
// "add bank account Salary at HNB opening 15000"
// "add card account Sampath Visa at Sampath Bank limit 250000 opening 0"
// fields: type (bank|card), name, institution, openingBalanceLKR?, creditLimitLKR?, numberMasked?
function parseAddAccount(textRaw) {
  if (!textRaw) return null;
  const text = textRaw.toLowerCase();

  // must mention add + (bank|card) + account
  if (!/\badd\b/.test(text) || !/\baccount\b/.test(text)) return null;
  const type = /\bcard\b/.test(text) ? "card" : (/\bbank\b/.test(text) ? "bank" : null);
  if (!type) return null;

  // name: we try to capture after "account" up to " at " if present
  // e.g., "add bank account Salary at HNB"
  const nameMatch =
    /account\s+([^@]*?)\s+at\s+/i.exec(textRaw) ||
    /account\s+(.+?)$/i.exec(textRaw);
  const name = nameMatch ? nameMatch[1].trim() : null;

  // institution after " at "
  const instMatch = /\sat\s+([A-Za-z0-9().\-\s]+?)(?:\s+(opening|limit|with|number|mask|$))/i.exec(textRaw + " ");
  let institution = instMatch ? instMatch[1].trim() : null;

  // opening amount: phrases "opening 15000" or "opening LKR 15,000"
  const openMatch = /(opening|with\s+opening)\s+([0-9][0-9,\.]*)/i.exec(textRaw);
  const openingBalanceLKR = openMatch ? Number(openMatch[2].replace(/,/g, "")) : undefined;

  // card limit: "limit 250000" or "credit limit 250000"
  const limitMatch = /(limit|credit\s+limit)\s+([0-9][0-9,\.]*)/i.exec(textRaw);
  const creditLimitLKR = limitMatch ? Number(limitMatch[2].replace(/,/g, "")) : undefined;

  // optional number mask: "number **** 4321" or "mask ****4321"
  const maskMatch = /(number|mask)\s+([*xX•\s0-9]{4,})/i.exec(textRaw);
  const numberMasked = maskMatch ? maskMatch[2].replace(/\s+/g, "").trim() : undefined;

  // basic sanity
  if (!name) return null;
  if (!institution) institution = "Other";
  // normalize institution to one of known banks if a substring matches
  const matchInst = BANKS_LK.find(b => b.toLowerCase().includes(institution.toLowerCase()))
    || BANKS_LK.find(b => institution.toLowerCase().includes(b.toLowerCase()))
    || (BANKS_LK.includes(institution) ? institution : "Other");

  return {
    type,
    name,
    institution: matchInst,
    openingBalanceLKR,
    creditLimitLKR: type === "card" ? creditLimitLKR : undefined,
    numberMasked,
  };
}

function validateAccountPayload(p) {
  const errs = [];
  if (!["bank", "card"].includes(p.type)) errs.push("type must be bank or card");
  if (!p.name?.trim()) errs.push("name required");
  if (!p.institution?.trim()) errs.push("institution required");
  if (!BANKS_LK.includes(p.institution)) p.institution = "Other";
  if (p.openingBalanceLKR != null && isNaN(p.openingBalanceLKR)) errs.push("openingBalanceLKR invalid");
  if (p.type === "card" && p.creditLimitLKR != null && isNaN(p.creditLimitLKR)) errs.push("creditLimitLKR invalid");
  if (errs.length) {
    const e = new Error(errs.join("; "));
    e.status = 400;
    throw e;
  }
  return p;
}

async function createAccountDoc(userId, draft) {
  validateAccountPayload(draft);
  const openingC = toCents(draft.openingBalanceLKR || 0);
  const creditC =
    draft.type === "card" && draft.creditLimitLKR != null
      ? toCents(draft.creditLimitLKR)
      : undefined;

  const doc = await Account.create({
    userId,
    type: draft.type,
    name: draft.name.trim(),
    institution: draft.institution.trim(),
    numberMasked: draft.numberMasked?.trim(),
    currency: "LKR",
    openingBalanceCents: openingC,
    balanceCents: openingC,
    creditLimitCents: creditC,
    archived: false,
  });
  return doc;
}

// ---------- minimal SSE streamer to OpenAI (text only) ----------
async function streamChatFromOpenAI({ messages, model = "gpt-4.1-mini" }, res) {
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");

  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ model, input: messages, stream: true }),
  });

  if (!r.ok || !r.body) {
    res.write(`data: ${JSON.stringify({ error: "openai_request_failed" })}\n\n`);
    return res.end();
  }

  const reader = r.body.getReader();
  const decoder = new TextDecoder();

  let buffer = "";
  function handleLines(lines) {
    let ev = null;
    for (const raw of lines) {
      const line = raw.trimEnd();
      if (line.startsWith("event:")) { ev = line.slice(6).trim(); continue; }
      if (line.startsWith("data:")) {
        const payload = line.slice(5).trimStart();
        if (!ev || payload === "[DONE]") continue;
        if (ev === "response.output_text.delta") {
          try {
            const obj = JSON.parse(payload);
            const piece = obj?.delta || "";
            if (piece) res.write(`data: ${piece}\n\n`);
          } catch {}
        }
        ev = null;
      }
    }
  }

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split(/\r?\n/);
      buffer = parts.pop() ?? "";
      handleLines(parts);
    }
  } catch {
    // aborted
  } finally {
    res.write("data: \n\n");
    res.end();
  }
}

// =====================================================
// ================  PUBLIC CONTROLLERS  ===============
// =====================================================

/**
 * POST /api/assist/chat
 * - If last message looks like an "add account" command (simple regex),
 *   we create it **for real** and reply once via SSE.
 * - Otherwise, we just stream model text.
 */
export async function chat(req, res) {
  try {
    const { messages, model } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0)
      return res.status(400).json({ error: "messages_required" });

    const userId = req.userId;
    if (!isObjId(userId))
      return res.status(401).json({ error: "Not logged in" });

    const lastText = messages[messages.length - 1]?.content || "";
    const parsed = parseAddAccount(lastText);

    if (parsed) {
      // create immediately
      try {
        const doc = await createAccountDoc(userId, parsed);
        const open = typeof parsed.openingBalanceLKR === "number"
          ? ` with opening LKR ${Number(parsed.openingBalanceLKR).toLocaleString("en-LK", { maximumFractionDigits: 2 })}`
          : "";
        const credit = parsed.type === "card" && typeof parsed.creditLimitLKR === "number"
          ? ` (credit limit LKR ${Number(parsed.creditLimitLKR).toLocaleString("en-LK", { maximumFractionDigits: 2 })})`
          : "";

        res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
        res.setHeader("Cache-Control", "no-cache, no-transform");
        res.setHeader("Connection", "keep-alive");
        res.write(`data: ✅ Created ${doc.type === "card" ? "card" : "bank"} account **${doc.institution} — ${doc.name}**${open}${credit}.\n\n`);
        res.write("data: \n\n");
        return res.end();
      } catch (e) {
        const detail = e?.message || "Failed to add account";
        res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
        res.setHeader("Cache-Control", "no-cache, no-transform");
        res.setHeader("Connection", "keep-alive");
        res.write(`data: ❌ Could not add account: ${detail}\n\n`);
        res.write("data: \n\n");
        return res.end();
      }
    }

    // otherwise: normal chat stream
    await streamChatFromOpenAI({
      messages: [
        { role: "system", content: "You are My Budget Pal. Answer briefly and helpfully. If user types math, compute it and return the number." },
        ...messages,
      ],
      model: model || "gpt-4.1-mini",
    }, res);

  } catch (err) {
    console.error("[assist/chat] error:", err);
    if (!res.headersSent) res.status(500).json({ error: "server_error" });
  }
}

/**
 * POST /api/assist/add-account-text
 * Body: { text: string }
 * Parses the text (no AI) and creates the account. Returns 201 with doc.
 */
export async function addAccountFromText(req, res) {
  try {
    const userId = req.userId;
    if (!isObjId(userId))
      return res.status(401).json({ error: "Not logged in" });

    const text = req.body?.text || "";
    const parsed = parseAddAccount(text);
    if (!parsed) return res.status(400).json({ error: "could_not_parse" });

    const doc = await createAccountDoc(userId, parsed);
    return res.status(201).json(doc);
  } catch (e) {
    if (e?.code === 11000) {
      return res.status(409).json({ error: "duplicate_name" });
    }
    return res.status(500).json({ error: "add_failed", detail: e?.message });
  }
}

/**
 * POST /api/assist/stt
 * multipart/form-data with field "audio"
 */
export async function stt(req, res) {
  if (!req.file) return res.status(400).json({ error: "audio_required" });
  if (!req.file.size) return res.status(400).json({ error: "empty_audio" });

  const tmp = req.file.path;
  try {
    const fallbackExt = guessExt(req.file.mimetype) || "webm";
    const filename = req.file.originalname && hasExt(req.file.originalname)
      ? req.file.originalname
      : `audio.${fallbackExt}`;
    const file = await toFile(fs.createReadStream(tmp), filename);
    const out = await oai().audio.transcriptions.create({
      file,
      model: "whisper-1",
    });
    const text = out?.text || "";
    if (!text) return res.status(422).json({ error: "no_transcript" });
    return res.json({ text });
  } catch (e) {
    const status = e?.status || 500;
    return res.status(status).json({
      error: status === 401 ? "openai_auth_failed" : "stt_failed",
      detail: e?.message,
    });
  } finally {
    fs.unlink(tmp, () => {});
  }
}

/**
 * POST /api/assist/tts
 * Body: { text, voice? }
 * Returns: audio/mpeg
 */
export async function tts(req, res) {
  try {
    const { text, voice = "alloy" } = req.body || {};
    if (!text || typeof text !== "string")
      return res.status(400).json({ error: "text_required" });

    const speech = await oai().audio.speech.create({
      model: "gpt-4o-mini-tts",
      voice,
      input: text,
      format: "mp3",
    });
    const buf = Buffer.from(await speech.arrayBuffer());
    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Content-Length", buf.length);
    return res.end(buf);
  } catch (e) {
    const status = e?.status || 500;
    return res.status(status).json({
      error: status === 401 ? "openai_auth_failed" : "tts_failed",
      detail: e?.message,
    });
  }
}
