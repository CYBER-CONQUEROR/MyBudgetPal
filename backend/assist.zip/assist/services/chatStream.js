// assist/services/chatStream.js
/**
 * Consume OpenAI Responses SSE and forward only text deltas as "data: <piece>\n\n".
 */
export async function streamChatFromOpenAI({ messages, model = "gpt-4.1-mini" }, res) {
  // SSE to the browser
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");

  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      input: messages,
      stream: true,
      // If you ever add tools, keep as-is; we only forward text deltas below.
    }),
  });

  if (!r.ok || !r.body) {
    res.write(`data: ${JSON.stringify({ error: "openai_request_failed" })}\n\n`);
    return res.end();
  }

  const reader = r.body.getReader();
  const decoder = new TextDecoder();

  // We’ll reconstruct SSE frames: look for "event:" lines followed by "data:" lines.
  let buffer = "";
  function handleLines(lines) {
    // We need to pair event + data. Keep tiny state.
    let pendingEvent = null;
    for (const raw of lines) {
      const line = raw.trimEnd();
      if (line.startsWith("event:")) {
        pendingEvent = line.slice(6).trim();
        continue;
      }
      if (line.startsWith("data:")) {
        const payload = line.slice(5).trimStart();

        // If it’s a plain keepalive or empty, skip
        if (!pendingEvent || payload === "[DONE]") continue;

        // We care only about "response.output_text.delta"
        if (pendingEvent === "response.output_text.delta") {
          try {
            const obj = JSON.parse(payload);
            const piece = obj?.delta || "";
            if (piece) {
              // Forward to the browser as a clean text chunk
              res.write(`data: ${piece}\n\n`);
            }
          } catch {
            // ignore malformed piece
          }
        }

        // On completed, we can just end (optional)
        if (pendingEvent === "response.completed") {
          // End after we’ve sent everything
          // not strictly necessary since upstream will end soon
        }
        // reset event slot until the next "event:"
        pendingEvent = null;
      }
      // ignore other lines
    }
  }

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // Split by newlines, keep last partial line in buffer
      const parts = buffer.split(/\r?\n/);
      buffer = parts.pop() ?? "";
      handleLines(parts);
    }
  } catch {
    // client aborted, ignore
  } finally {
    // Signal end of stream to client
    res.write("data: \n\n");
    res.end();
  }
}
