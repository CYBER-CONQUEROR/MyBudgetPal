// assist/routes.js
import { Router } from "express";
import multer from "multer";
import fs from "fs";
import { chat, stt, tts, addAccountFromText } from "./controller.js";

// ensure upload dir exists
fs.mkdirSync("uploads", { recursive: true });
const upload = multer({ dest: "uploads/" });

const router = Router();

// chat (SSE streaming, with simple "add account" interception)
router.post("/chat", chat);

// speech-to-text
router.post("/stt", upload.single("audio"), stt);

// text-to-speech
router.post("/tts", tts);

// direct “add account from text” endpoint (no AI NLU; simple regex parser)
router.post("/add-account-text", addAccountFromText);

export default router;
