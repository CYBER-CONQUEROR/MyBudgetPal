// assist/intents/addAccount.js
import "dotenv/config";
import Account from "../../AccountManagement/AccountModel.js"; // adjust if your path differs
import mongoose from "mongoose";
import { extractAddAccount, banksLK } from "../services/nlu.js";

const toCents = (lkr) => Math.round(Number(lkr || 0) * 100);

const problem = ({ status = 400, title = "Bad Request", detail }) => ({
  type: "about:blank",
  title, status, detail,
});

const isValidObjectId = (v) => mongoose.isValidObjectId(v);

function validatePayload(p) {
  const errs = [];
  if (!p || typeof p !== "object") errs.push("payload missing");
  if (!["bank", "card"].includes(p.type)) errs.push("type must be 'bank' or 'card'");
  if (!p.name || !p.name.trim()) errs.push("name is required");
  if (!p.institution || !p.institution.trim()) errs.push("institution is required");
  if (!banksLK.includes(p.institution)) p.institution = "Other";

  // numeric checks
  if (p.openingBalanceLKR != null && !(isFinite(p.openingBalanceLKR)))
    errs.push("openingBalanceLKR must be a number");

  if (p.type === "card" && p.creditLimitLKR != null && !(isFinite(p.creditLimitLKR)))
    errs.push("creditLimitLKR must be a number");

  if (errs.length) {
    const e = new Error(errs.join("; "));
    e.status = 400;
    throw e;
  }
  return p;
}

/**
 * Creates an account from either structured JSON or free text.
 * Body:
 *  - text?: string           // natural language (e.g., "add HNB bank account with 5,000 opening")
 *  - data?: { ... }          // structured fields (type, name, institution, ...)
 *
 * Returns: 201 with the created Account doc
 */
export async function intentAddAccount(req, res) {
  try {
    // auth (rely on your requireUser middleware)
    const userId = req.userId;
    if (!isValidObjectId(userId)) {
      return res.status(401).json(problem({ status: 401, title: "Unauthorized", detail: "No user" }));
    }

    const { text, data } = req.body || {};
    let draft = data;

    // If text provided, extract fields via NLU
    if (!draft && text && text.trim()) {
      draft = await extractAddAccount(text.trim());
    }
    if (!draft) {
      return res.status(400).json(problem({ detail: "Provide either 'text' or 'data' body." }));
    }

    // Normalize/validate
    validatePayload(draft);

    const openingBalanceCents = toCents(draft.openingBalanceLKR || 0);
    const creditLimitCents = draft.type === "card" && draft.creditLimitLKR != null
      ? toCents(draft.creditLimitLKR)
      : undefined;

    const doc = await Account.create({
      userId,
      type: draft.type,                   // 'bank' | 'card'
      name: draft.name.trim(),
      institution: draft.institution.trim(),
      numberMasked: draft.numberMasked?.trim(),
      currency: "LKR",
      openingBalanceCents,
      balanceCents: openingBalanceCents,
      creditLimitCents,
      archived: false,
    });

    return res.status(201).json(doc);
  } catch (e) {
    if (e?.code === 11000) {
      return res.status(409).json(problem({ title: "Conflict", detail: "Account name already exists" }));
    }
    const status = e?.status || 500;
    return res.status(status).json(problem({ status, title: "AddAccountFailed", detail: e?.message || "unknown" }));
  }
}
