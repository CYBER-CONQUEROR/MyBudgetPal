// assist/services/addAccountHandler.js
import "dotenv/config";
import mongoose from "mongoose";
import { getOpenAI } from "./openaiClient.js";
import Account from "../../AccountManagement/AccountModel.js";

// --- Sri Lankan banks ---
const banksLK = [
  "Bank of Ceylon (BOC)", "People's Bank", "National Savings Bank (NSB)",
  "Commercial Bank of Ceylon", "Hatton National Bank (HNB)", "Sampath Bank",
  "Seylan Bank", "DFCC Bank", "Nations Trust Bank", "NDB Bank (National Development Bank)",
  "Pan Asia Bank", "Union Bank of Colombo", "Cargills Bank", "Amãna Bank",
  "HSBC Sri Lanka", "Standard Chartered Sri Lanka", "Citibank Sri Lanka",
  "State Bank of India - Sri Lanka", "Indian Bank - Sri Lanka", "Indian Overseas Bank - Sri Lanka",
  "Habib Bank Ltd (HBL)", "MCB Bank", "Public Bank Berhad - Sri Lanka", "Other",
];

const toCents = (lkr) => Math.round(Number(lkr || 0) * 100);
const isValidObjectId = (v) => mongoose.isValidObjectId(v);

// --- NLU extraction ---
async function extractAddAccount(text) {
  const openai = getOpenAI();
  const sys = [
    "You extract structured account details as JSON only. No text output.",
    "Fields: {type:'bank'|'card', name:string, institution:string, numberMasked?:string, openingBalanceLKR?:number, creditLimitLKR?:number}",
    "Currency is always LKR.",
    `Valid institutions: ${banksLK.join(", ")}. If not listed, use 'Other'.`
  ].join(" ");
  const r = await openai.responses.create({
    model: "gpt-4.1-mini",
    input: [
      { role: "system", content: sys },
      { role: "user", content: text }
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "add_account",
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            type: { enum: ["bank", "card"] },
            name: { type: "string" },
            institution: { type: "string" },
            numberMasked: { type: "string" },
            openingBalanceLKR: { type: "number" },
            creditLimitLKR: { type: "number" },
          },
          required: ["type", "name", "institution"]
        }
      }
    }
  });
  const raw = r.output?.[0]?.content?.[0]?.text || r.output_text || "";
  return JSON.parse(raw);
}

// --- Validator ---
function validateAccountPayload(p) {
  const errs = [];
  if (!["bank", "card"].includes(p.type)) errs.push("type must be bank or card");
  if (!p.name?.trim()) errs.push("name required");
  if (!p.institution?.trim()) errs.push("institution required");
  if (!banksLK.includes(p.institution)) p.institution = "Other";
  if (p.openingBalanceLKR != null && isNaN(p.openingBalanceLKR))
    errs.push("openingBalanceLKR invalid");
  if (p.type === "card" && p.creditLimitLKR != null && isNaN(p.creditLimitLKR))
    errs.push("creditLimitLKR invalid");
  if (errs.length) {
    const e = new Error(errs.join("; "));
    e.status = 400;
    throw e;
  }
  return p;
}

// --- Actual DB creation ---
async function createAccount(userId, draft) {
  validateAccountPayload(draft);
  const openingBalanceCents = toCents(draft.openingBalanceLKR || 0);
  const creditLimitCents =
    draft.type === "card" && draft.creditLimitLKR != null
      ? toCents(draft.creditLimitLKR)
      : undefined;

  const doc = await Account.create({
    userId,
    type: draft.type,
    name: draft.name.trim(),
    institution: draft.institution.trim(),
    numberMasked: draft.numberMasked?.trim(),
    currency: "LKR",
    openingBalanceCents,
    balanceCents: openingBalanceCents,
    creditLimitCents,
    archived: false,
  });
  return doc;
}

// --- main export used by controller ---
export async function handleAddAccountIfNeeded(messages, userId, res) {
  const lastText = messages[messages.length - 1]?.content?.toLowerCase() || "";
  const looksLikeAdd =
    /\b(add|create|open|setup|set up)\b/.test(lastText) &&
    /\b(account|bank|card)\b/.test(lastText);
  if (!looksLikeAdd) return false;

  try {
    const extracted = await extractAddAccount(messages[messages.length - 1].content);
    if (!extracted?.type || !extracted?.name || !extracted?.institution) return false;
    const doc = await createAccount(userId, extracted);

    const open = extracted.openingBalanceLKR
      ? ` with opening LKR ${Number(extracted.openingBalanceLKR).toLocaleString("en-LK", { maximumFractionDigits: 2 })}`
      : "";
    const credit =
      extracted.type === "card" && extracted.creditLimitLKR
        ? ` (credit limit LKR ${Number(extracted.creditLimitLKR).toLocaleString("en-LK", { maximumFractionDigits: 2 })})`
        : "";

    const msg = `✅ Created ${doc.type === "card" ? "card" : "bank"} account **${doc.institution} — ${doc.name}**${open}${credit}.`;

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.write(`data: ${msg}\n\n`);
    res.end();
    return true;
  } catch (e) {
    const detail = e?.message || "Failed to add account";
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.write(`data: ❌ Could not add account: ${detail}\n\n`);
    res.end();
    return true;
  }
}
