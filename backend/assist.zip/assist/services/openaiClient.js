// assist/services/openaiClient.js
import OpenAI from "openai";
import "dotenv/config"; // optional extra safety if this file is ever run standalone

let _client = null;

export function getOpenAI() {
  if (_client) return _client;
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    throw new Error("[assist] OPENAI_API_KEY is not set");
  }
  _client = new OpenAI({ apiKey: key });
  return _client;
}
