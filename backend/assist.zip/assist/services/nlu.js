// assist/services/nlu.js
import "dotenv/config";
import { getOpenAI } from "./openaiClient.js";

const banksLK = [
  "Bank of Ceylon (BOC)", "People's Bank", "National Savings Bank (NSB)",
  "Commercial Bank of Ceylon", "Hatton National Bank (HNB)", "Sampath Bank",
  "Seylan Bank", "DFCC Bank", "Nations Trust Bank", "NDB Bank (National Development Bank)",
  "Pan Asia Bank", "Union Bank of Colombo", "Cargills Bank", "Amãna Bank",
  "HSBC Sri Lanka", "Standard Chartered Sri Lanka", "Citibank Sri Lanka",
  "State Bank of India - Sri Lanka", "Indian Bank - Sri Lanka", "Indian Overseas Bank - Sri Lanka",
  "Habib Bank Ltd (HBL)", "MCB Bank", "Public Bank Berhad - Sri Lanka", "Other",
];

export async function extractAddAccount(text) {
  const openai = getOpenAI();
  // Ask for strict JSON output with the fields we need
  const sys = [
    "You are an extraction engine. Output ONLY valid JSON, no prose.",
    "Fields: {type:'bank'|'card', name:string, institution:string, numberMasked?:string, openingBalanceLKR?:number, creditLimitLKR?:number}",
    "Currency is always LKR. If not provided, openingBalanceLKR=0. If type is 'card' and user mentions limit, set creditLimitLKR; else omit.",
    `Valid institutions (Sri Lanka): ${banksLK.join(", ")}. If user says something else, use "Other".`,
  ].join(" ");

  const r = await openai.responses.create({
    model: "gpt-4.1-mini",
    input: [
      { role: "system", content: sys },
      { role: "user", content: text }
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "add_account",
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            type: { enum: ["bank", "card"] },
            name: { type: "string" },
            institution: { type: "string" },
            numberMasked: { type: "string" },
            openingBalanceLKR: { type: "number" },
            creditLimitLKR: { type: "number" },
          },
          required: ["type", "name", "institution"]
        }
      }
    }
  });

  // The SDK returns text for json_schema; parse it
  const raw = r.output?.[0]?.content?.[0]?.text || r.output_text || "";
  return JSON.parse(raw);
}

export { banksLK };
